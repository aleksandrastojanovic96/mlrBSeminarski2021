#include <iostream>
#include <math.h>
using namespace std;

int main ()
{
    
int a, b, c;

cin >> a >> b >> c ;

if(a+b>=c || b+c >=a || a+c>=b){
    if(pow(a,2)+ pow(b,2)==pow(c,2))
       std::cout << "DA" << std::endl;
    else if(pow(a,2)+ pow(c,2)==pow(b,2))
        std::cout << "DA" << std::endl;
    else if(pow(b,2)+ pow(c,2)==pow(a,2))
        std::cout << "DA" << std::endl;
    else
        std::cout << "NE" << std::endl; 
    
}


return 0;
}



    
