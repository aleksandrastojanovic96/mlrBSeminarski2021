a=int(input())
b=int(input())
c=int(input())

if a+b>=c or a+c>=b or b+c>=a :
    if(a**2+b**2==c**2):
        print('DA')
    elif(b**2+c**2==a**2):
        print('DA')
    elif(a**2+c**2==b**2):
        print('DA')
    else :
        print('NE')