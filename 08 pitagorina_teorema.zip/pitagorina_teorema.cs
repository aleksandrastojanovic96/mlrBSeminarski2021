
using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {

            int a, b, c;
         

            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            c = int.Parse(Console.ReadLine());

            if (a + b >= c || b + c >= a || a + c >= b)
            {
                if (Math.Pow(a, 2) + Math.Pow(b, 2) == Math.Pow(c, 2))
                    Console.WriteLine("DA");
                else if (Math.Pow(c, 2) + Math.Pow(b, 2) == Math.Pow(a, 2))
                    Console.WriteLine("DA");

                else if (Math.Pow(c, 2) + Math.Pow(a, 2) == Math.Pow(b, 2))
                    Console.WriteLine("DA");

                else
                    Console.WriteLine("NE");

            }




            Console.ReadKey();

        }
    }
}



    
