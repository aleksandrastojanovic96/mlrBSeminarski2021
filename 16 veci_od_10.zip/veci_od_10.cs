using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            int [] niz=new int[10];

            for (int i = 0; i < 10; i++)
            {
                niz[i] = Console.ReadLine();
                
            }

            for (int i = 0; i < 10; i++)
            {
                if (niz[i] > 10)
                    Console.WriteLine(niz[i]);
            }




                Console.ReadKey();

        }
    }
}