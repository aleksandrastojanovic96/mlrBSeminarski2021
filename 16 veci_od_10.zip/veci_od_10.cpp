#include <iostream>
using namespace std;

int main()
{
   int i;
   int niz[10];
   
   for(i=0;i<10;i++){
       std::cin >> niz[i];
   }
   
   for(i=0;i<10;i++){
       if(niz[i]>10)
       std::cout << niz[i] << std::endl;
   }
   
   
   
	return 0;
}