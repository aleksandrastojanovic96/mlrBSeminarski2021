niz = []
for i in range(10):
    e = int(input())
    niz.append(e)

for e in niz:
    if e>10:
        print(e)