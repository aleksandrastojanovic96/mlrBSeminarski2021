#include <iostream>
using namespace std;

int main()
{
    int i, zbir=0;
    int niz[15];
    
    for(i=0;i<15;i++){
    std::cin >> niz[i];
    zbir+=niz[i];
    }
    
    int prosek=0;
    prosek=zbir/15;
    
    std::cout << prosek << std::endl;
	return 0;
}