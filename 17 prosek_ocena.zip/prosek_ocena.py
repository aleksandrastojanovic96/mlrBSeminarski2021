ocene = []
for i in range(15):
    ocena = int(input())
    ocene.append(ocena)
prosek = sum(ocene) / len(ocene)
print(prosek)