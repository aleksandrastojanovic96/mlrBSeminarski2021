using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {

        int i, zbir = 0;
        int[] niz=new int[15];

        for (i = 0; i < 15; i++)
        {
            niz[i]=Console.ReadLine();
            zbir += niz[i];
        }

        int prosek = 0;
        prosek = zbir / 15;

        Console.WriteLine(prosek);
  



    Console.ReadKey();

        }
    }
}