c0=int(input())



if (0+c0)%3==0 :
    print(c0)
if (1+c0)%3==0 :
    print(1*10+c0)
if (2+c0)%3==0 :
    print(2*10+c0)
if (3+c0)%3==0 :
    print(3*10+c0)
if (4+c0)%3==0 :
    print(4*10+c0)
if (5+c0)%3==0 and c0<6 :
    print(5*10+c0)