#include <iostream>
#include <math.h>
using namespace std;

int main ()
{
    
int c0;

cin >> c0 ;

if((0+c0)%3==0) 
    std::cout << c0 << std::endl;
if((1+c0)%3==0) 
    std::cout << 1*10+c0 << std::endl;
if((2+c0)%3==0) 
    std::cout << 2*10+c0 << std::endl;
if((3+c0)%3==0) 
    std::cout << 3*10+c0 << std::endl;
if((4+c0)%3==0) 
    std::cout << 4*10+c0 << std::endl;
if((5+c0)%3==0 && c0<6) 
    std::cout << 5*10+c0 << std::endl;



return 0;
}