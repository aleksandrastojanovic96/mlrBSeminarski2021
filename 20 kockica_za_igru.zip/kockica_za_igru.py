kockica=(1, 2, 3, 4, 5, 6)

indeksi=[10]

broj=int(input())

for i in range(10):
    indeksi[i]=0
    
j=0 
while j<10:
    if broj==kockica[0]:
        indeksi[j]=1 
    elif broj==kockica[1]:
          indeksi[j]=2
    elif broj==kockica[2]:
        indeksi[j]=3
    elif broj==kockica[3]:
        indeksi[j]=4
    elif broj==kockica[4]:
        indeksi[j]=5
    elif broj==kockica[5]:
        indeksi[j]=6
j+=1 


for i in range(10):
    print(indeksi[i])
