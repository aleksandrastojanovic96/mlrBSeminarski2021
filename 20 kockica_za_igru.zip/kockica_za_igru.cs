
using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] kockica = { 1, 2, 3, 4, 5, 6 };
            int[] indeksi = new int[10];
            int i = 0;
            int broj;
            while (i < 10)
            {
                broj = Console.ReadLine();
                if (broj == kockica[0])
                    indeksi[i] = 1;
              else  if (broj == kockica[1])
                    indeksi[i] = 2;
              else  if (broj == kockica[2])
                    indeksi[i] = 3;
              else  if (broj == kockica[3])
                    indeksi[i] = 4;
              else  if (broj == kockica[4])
                    indeksi[i] = 5;
              else  if (broj == kockica[5])
                    indeksi[i] = 6;

                i++;

            }


            for (i = 0; i < 10; i++)
                Console.WriteLine(indeksi[i]);
            Console.ReadKey();

        }
    }
}