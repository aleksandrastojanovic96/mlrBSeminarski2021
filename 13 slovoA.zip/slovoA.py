n=int(input())
x=1
brojac=0
while x<=n:
    rec=input()
    x+=1
    for i in range(1,len(rec)):
        if rec[i]=='a':
           brojac+=1
           
print(brojac) 