using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {


        int n;
        int i;
        int brojac = 0;

        string s;

            n = int.Parse(Console.ReadLine());

        for (i = 1; i <= n; i++)
        {
                s = Console.ReadLine();
                if (s[i] == 'a')
                    brojac++;
        }

            Console.WriteLine(brojac);


   
    Console.ReadKey();

        }
    }
}