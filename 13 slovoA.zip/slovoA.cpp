#include <iostream>
using namespace std;

int main()
{
  
  int n;
  int i;
  int brojac=0;
  
  string s;
  
  std::cin >> n;
  
  for(i=1;i<=n;i++){
      std::cin >> s;
      if(s[i]=='a')
       brojac++;
  }
  
  std::cout << brojac << std::endl;
  
  
	return 0;
}