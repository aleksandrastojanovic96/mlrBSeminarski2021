#include <iostream>
using namespace std;

int main()
{
   int i;
   for(i=15;i>=1;i--)
   std::cout << i << std::endl;
	return 0;
}