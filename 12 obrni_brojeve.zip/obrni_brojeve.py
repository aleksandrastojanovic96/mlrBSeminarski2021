x=15;
while x>=1:
    print(x )
    x-=1