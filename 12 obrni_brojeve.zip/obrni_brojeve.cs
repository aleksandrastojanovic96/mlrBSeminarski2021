using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {

        int i;
     

        for (i = 15; i >= 1; i--)
        {
                Console.WriteLine(i);
            }

           


    Console.ReadKey();

        }
    }
}