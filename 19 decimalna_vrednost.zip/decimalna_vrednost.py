razlomak = input()
crta = razlomak.find("/")
brojilac = int(razlomak[0: crta])    
imenilac = int(razlomak[crta+1:])
decimalna_vrednost= brojilac/ imenilac
print(decimalna_vrednost)