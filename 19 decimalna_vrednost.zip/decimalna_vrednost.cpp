#include <iostream>
#include<string>
using namespace std;

int main()
{
   string razlomak;
   int crta;
   int brojilac, imenilac;
   double decimalna_vrednost=0;
   
   std::cin >> razlomak;
   crta=razlomak.find('/');
   
   brojilac=razlomak.substr(0,crta);
   imenilac=razlomak.substr(crta+1,razlomak.length-1);
   
   decimalna_vrednost=brojilac/imenilac;
   std::cout << decimalna_vrednost << std::endl;
   
   
	return 0;
}