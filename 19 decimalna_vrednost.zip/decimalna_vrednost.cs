using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {

            string razlomak;
            int crta;
            int brojilac=0, imenilac=0;
            double decimalna_vrednost = 0;

            razlomak = Console.ReadLine();
            crta = razlomak.IndexOf('/');

            brojilac = int.Parse(razlomak.Substring(0, crta));
            imenilac = int.Parse(razlomak.Substring(crta + 1,razlomak.Length));

            decimalna_vrednost = brojilac / imenilac;

            Console.WriteLine(decimalna_vrednost);

            Console.ReadKey();

        }
    }
}