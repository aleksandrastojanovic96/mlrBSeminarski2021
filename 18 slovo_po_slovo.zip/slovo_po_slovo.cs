
using System;
class HelloWorld {
  static void Main() {
      
  string rec;
  rec=Console.ReadLine();
  
  foreach (char c in rec)
     Console.WriteLine(c);
      
    
  }
}