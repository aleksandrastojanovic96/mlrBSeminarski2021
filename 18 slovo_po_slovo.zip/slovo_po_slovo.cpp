#include <iostream>
#include<string>
using namespace std;

int main()
{
   string rec;
   std::cin >> rec;
   
   int i=0;
   while(i<rec.length()){
   std::cout << rec[i] << std::endl;
   i++;
   }
	return 0;
}