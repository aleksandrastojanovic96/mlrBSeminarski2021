niska = input()
for c in niska:
    print(c)