#include <iostream>
#include<string>
using namespace std;

int main()
{
   string s;
   
   std::cin >> s;
   
int indZ=0;
int indL=0;
int indA=0;
int indT=0;
int indO=0;
int i;

for(i=0;i<s.length();i++){
    if (s[i]=='z')
        indZ=1;
    else if (s[i]=='l')
        indL=1;
    else if (s[i]=='a')
        indA=1;
    else if (s[i]=='t')
        indT=1;
    else if (s[i]=='o')
        indO=1; 
}
   
if(indO!=0 && indA!=0 && indT!=0 && indL!=0 && indZ!=0)
   std::cout << 1 << std::endl;
else
   std::cout << 0 << std::endl;
    
   
	return 0;
}