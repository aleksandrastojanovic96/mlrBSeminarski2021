using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {
            string s;

            s = Console.ReadLine();

            int indZ = 0;
            int indL = 0;
            int indA = 0;
            int indT = 0;
            int indO = 0;
            int i;

            for (i = 0; i < s.Length; i++)
            {
                if (s[i] == 'z')
                    indZ = 1;
                else if (s[i] == 'l')
                    indL = 1;
                else if (s[i] == 'a')
                    indA = 1;
                else if (s[i] == 't')
                    indT = 1;
                else if (s[i] == 'o')
                    indO = 1;
            }

            if (indO != 0 && indA != 0 && indT != 0 && indL != 0 && indZ != 0)
                Console.WriteLine(1);
            else
                Console.WriteLine(0);



            Console.ReadKey();

        }
    }
}