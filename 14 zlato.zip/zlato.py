s=input()
indZ=0
indL=0
indA=0
indT=0
indO=0
for i in range(1,len(s)):
    if s[i]=='z':
        indZ=1
    elif s[i]=='l':
        indL=1
    elif s[i]=='a':
        indA=1
    elif s[i]=='t':
        indT=1 
    elif s[i]=='o':
        indO=1 

if(indO!=0 and indA!=0 and indT!=0 and indL!=0 and indZ!=0):
    print(1)
else:
    print(0)
    