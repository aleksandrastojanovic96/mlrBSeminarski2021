using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            int zbir = 0;

            for (int i = 1; i < 8; i++)
            {
                n = int.Parse(Console.ReadLine());
                zbir += n;
            }

            Console.WriteLine(zbir);




            Console.ReadKey();

        }
    }
}