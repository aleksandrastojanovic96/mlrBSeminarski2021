zbir=0

for x in range(1,8):
    n=int(input())
    zbir+=n
    
print(zbir)