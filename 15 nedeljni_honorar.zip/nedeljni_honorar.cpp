#include <iostream>
using namespace std;

int main()
{
    int n;
    int zbir=0;
    
    for(int i=1;i<8;i++){
        std::cin >> n;
        zbir+=n;
    }
    
    std::cout << zbir << std::endl;
    
    
    
    
	return 0;
}