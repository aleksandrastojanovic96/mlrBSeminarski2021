vreme_polaska=int(input())
vreme_dolaska=int(input())

vreme=vreme_dolaska - vreme_polaska

predjeni_put=95*vreme
print(predjeni_put)