using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {
            int vreme1, vreme2;
            int vreme = 0;
       
            vreme1= int.Parse(Console.ReadLine());
            vreme2 = int.Parse(Console.ReadLine());

            vreme = vreme2 - vreme1;

            Console.WriteLine(95*vreme);

            Console.ReadKey();

        }
    }
}