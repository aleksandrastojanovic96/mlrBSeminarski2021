#include <iostream>

using namespace std;

int main(){

	int vreme1, vreme2;
	int vreme=0;
	int predjeni_put=0;
	
  
	cin >> vreme1 >> vreme2;
	
	vreme=vreme2-vreme1;
	
	predjeni_put=95*vreme;
	
	
	cout << predjeni_put << endl;


	return 0;
}