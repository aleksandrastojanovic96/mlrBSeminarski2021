broj_predmeta=int(input())

broj_ljudi=int(input())



print(broj_predmeta//broj_ljudi)