using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {

            int br1, br2;
            string s;

            br1 = int.Parse(Console.ReadLine());
            br2 = int.Parse(Console.ReadLine());
            s = Console.ReadLine();

            if (s == "+")
                Console.WriteLine(br1 + br2);
            else if(s=="-")
                Console.WriteLine(br1 - br2);
            else if(s=="*")
                Console.WriteLine(br1 * br2);
            else if(s=="/")
                Console.WriteLine(br1 / br2);
            Console.ReadKey();

        }
    }
}