using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {
            int prvi_broj, drugi_broj;
            int poslednja1 = 0, poslednja2 = 0;

            prvi_broj= int.Parse(Console.ReadLine());

            drugi_broj = int.Parse(Console.ReadLine());

            poslednja1 = prvi_broj % 10;
            poslednja2 = drugi_broj % 10;
            
            if(poslednja1==poslednja2)
                Console.WriteLine("DA");
            else
                Console.WriteLine("NE");


            Console.ReadKey();

        }
    }
}