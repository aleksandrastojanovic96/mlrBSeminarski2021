prvi_broj=int(input())
drugi_broj=int(input())

poslednja1=prvi_broj%10
poslednja2=drugi_broj%10

if poslednja1==poslednja2:
    print('DA')
else:
    print('NE')