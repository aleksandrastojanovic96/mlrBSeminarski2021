#include <iostream>

using namespace std;

int main(){

	int prvi_broj, drugi_broj;
	int c1=0, c2=0;

	
  
	cin >> prvi_broj >> drugi_broj;
	
	c1=prvi_broj%10;
	c2=drugi_broj%10;
	
	if(c1==c2)
	cout << "DA" << endl;
	
	else
	cout << "NE" << endl;


	return 0;
}