vreme=input()

s=vreme[0]

if (9<=s and s<17) :
    print('DA')
else
    print('NE')