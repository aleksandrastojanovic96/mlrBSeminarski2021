using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {
            int vreme;
            string[] str;

            str = Console.ReadLine().Split();
            vreme = int.Parse(str[0]);

            if (9 <= vreme && vreme < 17)
                Console.WriteLine("DA");
            else
                Console.WriteLine("NE");
          

            Console.ReadKey();

        }
    }
}