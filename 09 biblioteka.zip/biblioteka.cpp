#include <iostream>
#include <string>
using namespace std;

int main ()

{
    string vreme;
    
    
    cin >> vreme ;
    
    if(9<= vreme[0] && vreme[0]<17)
    
    std::cout << "DA" << std::endl;
    
    else
    
    std::cout << "NE" << std::endl;
    
    
    
    
    
    
    return 0;
}