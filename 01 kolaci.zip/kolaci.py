broj_gostiju=int(input())

print(240//broj_gostiju)

