using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {

   

        int a, b;
        int i;
        int br = 0;

        a = int.Parse(Console.ReadLine());
        b = int.Parse(Console.ReadLine());

        for (i = a; i <= b; i++)
        {
            if (i % 5 == 0)
                br++;
        }

            Console.WriteLine(br);


    Console.ReadKey();

        }
    }
}