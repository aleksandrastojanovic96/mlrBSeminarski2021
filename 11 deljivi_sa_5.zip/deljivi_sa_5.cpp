#include <iostream>
using namespace std;

int main()
{
 
 int a, b;
 int i;
 int br=0;
 
 std::cin >> a >> b;
 
 for(i=a;i<=b;i++){
     if(i%5==0)
     br++;
 }
 
 std::cout << br << std::endl;
 
 
 
 
 
 
 return 0;
}