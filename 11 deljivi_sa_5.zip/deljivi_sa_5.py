a=int(input())
b=int(input())
br=0

for x in range(a,b):
    if(x%5==0):
        br+=1

print(br)