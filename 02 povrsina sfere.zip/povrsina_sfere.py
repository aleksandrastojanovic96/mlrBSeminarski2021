import math

obim_velikog_kruga=int(input())

poluprecnik=obim_velikog_kruga//2

povrsina=4*math.pow(poluprecnik,2)

print(povrsina)