using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {
            int obim_velikog_kruga;
            double poluprecnik=0, povrsina=0;

           

            obim_velikog_kruga = int.Parse(Console.ReadLine());

            poluprecnik = obim_velikog_kruga / 2;

            povrsina = 4 * Math.Pow(poluprecnik, 2);

            Console.WriteLine(povrsina);

            Console.ReadKey();

        }
    }
}