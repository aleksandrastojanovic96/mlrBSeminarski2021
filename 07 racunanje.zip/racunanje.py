br1=int(input())
br2=int(input())
s=input()


  
if (s=="+") :
    print(br1+br2)
if (s=="-") :
    print(br1-br2)
if (s=="*") :
    print(br1*br2)
if (s=="/") :
    print(br1//br2)