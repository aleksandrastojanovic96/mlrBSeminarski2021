#include <iostream>

using namespace std;

int main(){


    int br1, br2;
    string s;
	
  
	cin >> br1 >> br2 >> s;
	

	
	if(s=="+")
	cout << br1+br2 << endl;

    else if(s=="-")
	cout << br1-br2 << endl;
	
	else if(s=="*")
	cout << br1*br2 << endl;
	
	 else if(s=="/")
	cout << br1/br2 << endl;

	return 0;
}