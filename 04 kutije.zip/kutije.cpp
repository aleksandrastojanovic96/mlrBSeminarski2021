#include <iostream>

using namespace std;

int main(){

	int duzina_klupe;
	
  
	cin >> duzina_klupe;
	
	cout << duzina_klupe/10 << endl;


	return 0;
}