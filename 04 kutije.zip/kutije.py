duzina_klupe=int(input())

print(duzina_klupe//10)