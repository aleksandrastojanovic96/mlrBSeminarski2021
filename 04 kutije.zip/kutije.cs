using System;
using System.Linq;

namespace ConsoleApp21
{
    class Program
    {
        static void Main(string[] args)
        {
            int duzina_klupe;
    
       
            duzina_klupe= int.Parse(Console.ReadLine());

            Console.WriteLine(duzina_klupe/10);

            Console.ReadKey();

        }
    }
}